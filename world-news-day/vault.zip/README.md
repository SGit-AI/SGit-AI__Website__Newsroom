# World News Day 2026 — the vault

21 commissioned op-eds, fetched once on 2026-09-29, frozen to
bytes, hashed, described, classified and graphed. Everything the published section stands on,
in one file.

Built by newsroom.sgit.ai. The live section: https://newsroom.sgit.ai/world-news-day/

## Two sets of terms, and they are not the same

**Ours** — everything under `data/` and `build/`, and this file: **CC BY 4.0**
(https://creativecommons.org/licenses/by/4.0/). Named, versioned, with a URL, and declared in
machine-readable form in `licence.json`. That is deliberate: this section's finding is that the
corpus it describes has no such declaration, and it would be cheap to say so without doing it.

**Theirs** — everything under `sources/frozen/`: the twenty-one op-eds as served, and the
records the publisher's own REST API returns for them. **Not ours, not relicensed, and not
reproduced as prose anywhere in our files.** Each piece carries this sentence, and it is the
only statement of terms anywhere on it:

> This opinion piece was commissioned to mark World News Day, on 28 September. Free to republish or translate in full, provided translations remain faithful to the original meaning. Minor edits for length or house style are permitted on the same basis.

A second wording appears on one of the 21, and the announcement page states the
terms a third way. What that does and does not permit is set out in `data/licences.json` and at
https://newsroom.sgit.ai/world-news-day/licences.html. **If you are deciding whether you may
republish one of these pieces, read the terms on the piece and ask the publisher.** Nothing here
is legal advice, and nothing here grants you anything over somebody else's work.

## Layout

```
README.md              this file
licence.json           our terms, in the schema.org field the corpus leaves empty
MANIFEST.json          every file in the bundle with its size and SHA-256
PACKAGE.sh             the commands that turn this folder into an sgit vault
data/
  register.json        every frozen file, its URL, retrieval time, size and SHA-256,
                       and the one page that could not be fetched, with the reason
  corpus.json          the 21 described — and never their prose
  licences.json        the licence finding, counted
  affiliations.json    where each author works, transcribed from their own role line
  analysis.json        the aggregate: themes, co-occurrence, the evidence count
  lexicon.json         the 20 published theme patterns — the only classification here
  ontology.json        types and verbs, each with a named inverse and a Portuguese form
  graph.json           the graph
  triples.nt           the same graph as N-Triples, owl:inverseOf on every verb
build/                 the code that produced all of it, including the gate that checks it
sources/frozen/2026-09-29/
  <slug>.snapshot      the page as served
  api/<slug>.json      the record the publisher's REST API returns
```

## Checking it

Nothing here asks to be taken on trust.

```bash
python3 - <<'EOF'
import hashlib, json
m = json.load(open("MANIFEST.json"))
bad = [f["path"] for f in m["files"]
       if hashlib.sha256(open(f["path"], "rb").read()).hexdigest() != f["sha256"]]
print("files:", m["count"], "| mismatched:", bad or "none")
EOF

python3 build/gates.py     # re-derives every published count from the frozen bytes
```

`build/gates.py` is the executable specification: it re-hashes every frozen file, re-derives
every licence count with a second implementation, re-runs every theme pattern on the frozen
prose in both directions, checks every transcribed affiliation against the bytes it claims to
come from, and fails if twelve consecutive words of any op-ed appear on a page we generate.

## What is NOT here

- **The prose of the op-eds, as text in any file we wrote.** It is in the frozen pages, because
  those are the evidence; it is in none of our JSON. Read the pieces at worldnewsday.org.
- **Any contact detail for any named person.** Refused where the data is parsed, not hidden
  where it is rendered.
- **Any assessment of anybody.** No sentiment, no stance, no scoring, no claim that any author
  agrees with any other. `agrees_with` is a banned verb in the ontology.
- **The announcement page.** wan-ifra.org answered an automated reader with HTTP 307 and no
  body, from two user-agents, while rendering normally for a browser. `data/register.json`
  records the refusal rather than hiding it.

107 files in the bundle, frozen 2026-09-29. The bundle is
built deterministically: the same frozen bytes produce the same zip, hash for hash.
