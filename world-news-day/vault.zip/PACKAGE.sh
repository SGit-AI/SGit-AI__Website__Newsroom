#!/usr/bin/env bash
# Turn this folder into an sgit vault. Requires an SG/Send access token, which is why the
# newsroom could not run it: the build environment has no credential, and a section about
# licensing does not invent one.
#
#   pip3 install sgit-ai
#   export SGIT_TOKEN=...        # your SG/Send access token
#
set -euo pipefail
VAULT_ID="wnd-2026-09-29"

sgit init "$VAULT_ID" --token "$SGIT_TOKEN"    # PRINTS THE VAULT KEY. Keep it. It is write access.
cd "$VAULT_ID"
cp -R ../data ../sources ../build ../README.md ../MANIFEST.json ../licence.json .
sgit commit "world news day 2026: 111 files, 2026-09-29"
sgit push
sgit history log --json

# Handing it over: publish the READ KEY, derived one-way from the vault key, and never the
# vault key itself. A read key grants read and only read:
#   python3 -c "from sgit_ai.vault.crypto import Vault__Crypto; \
#     print(Vault__Crypto().derive_keys(VAULT_KEY, '$VAULT_ID')['read_key'])"
# Or hand over a one-shot share token instead:  sgit share
