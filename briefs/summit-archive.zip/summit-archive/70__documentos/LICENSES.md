# Licences

This repository carries two licences, and a third that applies to a specific subset of
content it republishes.

> **Code** in this repository is licensed under the Apache License 2.0 (see `LICENSE`).
>
> **This site's own documentation and written content** — every `.html` page,
> `index.md`, `llms.txt`, and the brief pack in `briefs/` — is licensed under the
> Creative Commons Attribution 4.0 International licence (CC BY 4.0), unless a specific
> page states otherwise.

## What that means here

| Path | Licence |
|---|---|
| `admin/build/*.py`, `admin/build/*.js`, `assets/*.js`, `assets/*.css`, `.github/workflows/*` | Apache License 2.0 |
| `briefs/*.md`, `briefs/*.csv`, `briefs/*.json`, `index.md`, `llms.txt`, every `*.html` page | CC BY 4.0 |

## Third-party code vendored in this repository

| Path | Component | Licence |
|---|---|---|
| `assets/vendor/cytoscape.min.js` | [Cytoscape.js](https://js.cytoscape.org/) v3.30.2 — the graph engine behind `/portugal/graph.html`, the same build graphs.sgit.ai vendors for its own graph pages | MIT, © 2016-2024 The Cytoscape Consortium |
| `assets/vendor/sql-wasm.js`, `assets/vendor/sql-wasm.wasm` | [sql.js](https://sql.js.org/) v1.14.2 — SQLite compiled to WebAssembly, the engine behind `/databases/sql.html`; its licence text is kept beside it as `sql.js-LICENSE.txt` | MIT, © 2017 sql.js authors (SQLite itself is public domain) |
| `assets/vendor/oxigraph/web.js`, `assets/vendor/oxigraph/web_bg.wasm` | [Oxigraph](https://github.com/oxigraph/oxigraph) v0.5.11, web build — a SPARQL 1.1 store compiled to WebAssembly, the engine behind `/databases/graph.html` | MIT OR Apache-2.0, © Oxigraph contributors |
| `assets/fonts/newsreader-*.woff2`, `assets/fonts.css` | [Newsreader](https://github.com/productiontype/Newsreader) by Production Type — the serif of the pt.newsroom home-page design at `/pt-newsroom/`; latin subset, the woff2 files Google Fonts serves | SIL Open Font License 1.1, © 2020 The Newsreader Project Authors |
| `assets/fonts/plex-mono-*.woff2`, `assets/fonts.css` | [IBM Plex Mono](https://github.com/IBM/plex) by IBM — the monospace of the same design; latin subset | SIL Open Font License 1.1, © 2017 IBM Corp. |
| `assets/fonts/archivo-variable.woff2` | [Archivo](https://github.com/Omnibus-Type/Archivo) by Omnibus-Type — direction B of the archived pt.newsroom designs at `/pt-newsroom/directions.html` | SIL Open Font License 1.1 |
| `assets/fonts/jetbrains-mono-variable.woff2` | [JetBrains Mono](https://github.com/JetBrains/JetBrainsMono) by JetBrains — direction B | SIL Open Font License 1.1, © 2020 The JetBrains Mono Project Authors |
| `assets/fonts/space-grotesk-variable.woff2` | [Space Grotesk](https://github.com/floriankarsten/space-grotesk) by Florian Karsten — direction C | SIL Open Font License 1.1 |
| `assets/fonts/bodoni-moda-*.woff2` | [Bodoni Moda](https://github.com/indestructible-type/Bodoni) by indestructible type* — direction D | SIL Open Font License 1.1 |
| `assets/fonts/karla-variable.woff2` | [Karla](https://github.com/googlefonts/karla) by Jonny Pinhorn — direction D | SIL Open Font License 1.1 |
| `assets/vendor/marked.min.js` | [marked](https://github.com/markedjs/marked) v12.0.2 — the markdown parser behind the `/documents/` reader pages | MIT, © 2011-2024 Christopher Jeffrey and contributors |

It is vendored rather than loaded from a CDN deliberately. This is the site arguing that
an evidence chain should not terminate in a single third-party resource that could move,
change or disappear — so depending on one in order to read its own source documents would
have been the argument refuting itself.

## One limit specific to this site: the republished library

`library/index.html`, `economics/micro-and-nano-payments.html`, and the two
provenance-blocked sections on `rights/index.html` synthesise material first published
on [`docs.diniscruz.ai`](https://docs.diniscruz.ai), which is released under **CC0 1.0
Universal** — a public-domain dedication, not CC BY. These are different grants:

- **CC0** is more permissive than CC BY, so republishing CC0 material under this
  repository's CC BY 4.0 terms is legally sound.
- This repository's pages **cannot make the original more restrictive than it already
  is.** Every page deriving from `docs.diniscruz.ai` material states the source licence
  explicitly in its provenance block, per `briefs/02__source-provenance-and-attribution.md`.
- **This site does not claim verbatim reproduction of that material.** Every republished
  section is labelled with an honest curation status — see the provenance block on the
  page itself. Where a page is a synthesis, only this site's own summarising text is CC
  BY 4.0 content of this repository; the original remains CC0 at its source.

## Not included in this repository

Per `briefs/08__source-manifest.csv`, a small set of Tier 3 source material — a named
venture-capital firm, live product pricing, an internal investor review, and an
unbuilt source-protection design that would endanger a real source if published as a
working claim — is deliberately excluded from this repository and is not licensed for
publication here under any of the above.

## The decision behind it

Per a decision of 21 August 2026, applied across the `*.sgit.ai` estate: unless a
document explicitly says otherwise, content on a `*.sgit.ai` website is released under
CC BY 4.0. This site's own participant disclosure additionally argues that
`docs.diniscruz.ai` should align to CC BY 4.0 for future publication, leaving
already-published articles as CC0 — see `about/participant.html`.
